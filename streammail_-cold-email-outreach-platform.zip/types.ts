export interface Credentials {
  email: string;
  appPassword: string;
}

export interface Recipient {
  fullName: string;
  email: string;
  companyName: string;
  jobTitle?: string;
}

export interface EmailTemplate {
  subject: string;
  body: string;
  attachments?: File[];
}

export enum EmailStatus {
  Queued = 'Queued',
  Sending = 'Sending',
  Sent = 'Sent',
  Failed = 'Failed',
}

export interface SendProgressState {
  status: EmailStatus;
  error?: string;
}
