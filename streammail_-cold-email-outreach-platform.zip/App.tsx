import React, { useState, useCallback } from 'react';
import { Credentials, Recipient, EmailTemplate, EmailStatus, SendProgressState } from './types';
import StepIndicator from './components/StepIndicator';
import CredentialsForm from './components/CredentialsForm';
import RecipientUploader from './components/RecipientUploader';
import EmailComposer from './components/EmailComposer';
import ReviewAndSend from './components/ReviewAndSend';

// For SMTP.js library loaded via script tag
declare global {
  interface Window {
    Email: any;
  }
}

const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => resolve(reader.result as string);
        reader.onerror = error => reject(error);
    });
};

const App: React.FC = () => {
  const [step, setStep] = useState(1);
  const [credentials, setCredentials] = useState<Credentials | null>(null);
  const [recipients, setRecipients] = useState<Recipient[]>([]);
  const [emailTemplate, setEmailTemplate] = useState<EmailTemplate>({ subject: '', body: '', attachments: [] });
  const [sendProgress, setSendProgress] = useState<Record<string, SendProgressState>>({});
  const [isSending, setIsSending] = useState(false);
  const [isCampaignFinished, setIsCampaignFinished] = useState(false);
  const [scheduledTime, setScheduledTime] = useState<Date | null>(null);
  const [scheduleTimeoutId, setScheduleTimeoutId] = useState<number | null>(null);

  const totalSteps = 4;

  const handleNext = () => setStep((prev) => Math.min(prev + 1, totalSteps));
  const handleBack = () => setStep((prev) => Math.max(prev - 1, 1));

  const handleCredentialsSave = (creds: Credentials) => {
    setCredentials(creds);
    handleNext();
  };

  const handleRecipientsUpload = (newRecipients: Recipient[]) => {
    setRecipients(newRecipients);
    handleNext();
  };
  
  const handleTemplateUpdate = (template: EmailTemplate) => {
    setEmailTemplate(template);
    handleNext();
  };

  const startSendingProcess = useCallback((batchSize: number, batchDelay: number, recipientsToSend: Recipient[]) => {
    if (recipientsToSend.length === 0 || isSending || !credentials) return;

    setIsSending(true);
    setIsCampaignFinished(false);
    const initialProgress = recipientsToSend.reduce((acc, r) => {
      acc[r.email] = { status: EmailStatus.Queued };
      return acc;
    }, {} as Record<string, SendProgressState>);
    setSendProgress(initialProgress);

    let recipientIndex = 0;

    const sendBatch = () => {
        if (recipientIndex >= recipientsToSend.length) {
            setIsSending(false);
            setIsCampaignFinished(true);
            return;
        }

        const batch = recipientsToSend.slice(recipientIndex, recipientIndex + batchSize);
        let perEmailDelay = 0;

        for (const recipient of batch) {
            setTimeout(async () => {
                setSendProgress(prev => ({ ...prev, [recipient.email]: { status: EmailStatus.Sending } }));
                
                try {
                    const personalizedSubject = emailTemplate.subject
                        .replace(/{fullName}/g, recipient.fullName)
                        .replace(/{companyName}/g, recipient.companyName)
                        .replace(/{jobTitle}/g, recipient.jobTitle || '');

                    const personalizedBody = emailTemplate.body
                        .replace(/{fullName}/g, recipient.fullName)
                        .replace(/{companyName}/g, recipient.companyName)
                        .replace(/{jobTitle}/g, recipient.jobTitle || '');
                    
                    const attachmentsPayload = emailTemplate.attachments ? await Promise.all(
                        emailTemplate.attachments.map(async (file) => {
                            const dataUrl = await fileToBase64(file);
                            return {
                                name: file.name,
                                path: dataUrl,
                            };
                        })
                    ) : [];

                    await window.Email.send({
                        Host: "smtp.gmail.com",
                        Username: credentials.email,
                        Password: credentials.appPassword,
                        To: recipient.email,
                        From: credentials.email,
                        Subject: personalizedSubject,
                        Body: personalizedBody,
                        Attachments: attachmentsPayload,
                    });

                    setSendProgress(prev => ({ ...prev, [recipient.email]: { status: EmailStatus.Sent } }));

                } catch (err) {
                    const errorMessage = typeof err === 'string' ? err : (err as Error).message || 'An unknown error occurred.';
                    console.error("Email sending failed for:", recipient.email, err);
                    setSendProgress(prev => ({ ...prev, [recipient.email]: { status: EmailStatus.Failed, error: errorMessage } }));
                }

            }, perEmailDelay);
            perEmailDelay += 300; // Stagger emails within the batch
        }
        
        recipientIndex += batch.length;

        // After the last email in the batch has been "sent", schedule the next batch
        setTimeout(() => {
            sendBatch();
        }, (batchDelay * 1000) + perEmailDelay);
    };

    sendBatch(); // Start the first batch

  }, [isSending, credentials, emailTemplate]);

  const cancelSchedule = useCallback(() => {
    if (scheduleTimeoutId) {
        clearTimeout(scheduleTimeoutId);
    }
    setScheduledTime(null);
    setScheduleTimeoutId(null);
  }, [scheduleTimeoutId]);

  const handleScheduleOrSend = useCallback((config: { time: Date | null, batchSize: number, batchDelay: number, recipientsToSend: Recipient[] }) => {
    cancelSchedule(); // Clear any existing schedule first
    const { time, batchSize, batchDelay, recipientsToSend } = config;

    if (time && time.getTime() > Date.now()) {
        setScheduledTime(time);
        const delay = time.getTime() - Date.now();
        const timeoutId = window.setTimeout(() => {
            startSendingProcess(batchSize, batchDelay, recipientsToSend);
            setScheduledTime(null);
            setScheduleTimeoutId(null);
        }, delay);
        setScheduleTimeoutId(timeoutId);
    } else {
        setScheduledTime(null);
        startSendingProcess(batchSize, batchDelay, recipientsToSend);
    }
  }, [startSendingProcess, cancelSchedule]);

  const resetCampaign = () => {
    cancelSchedule();
    setStep(2); // Go to recipient upload for the next campaign
    setRecipients([]);
    setEmailTemplate({ subject: '', body: '', attachments: [] });
    setSendProgress({});
    setIsSending(false);
    setIsCampaignFinished(false);
  };

  const renderStepContent = () => {
    switch (step) {
      case 1:
        return <CredentialsForm onSave={handleCredentialsSave} />;
      case 2:
        return <RecipientUploader onUpload={handleRecipientsUpload} onBack={handleBack} />;
      case 3:
        return <EmailComposer initialTemplate={emailTemplate} onSave={handleTemplateUpdate} onBack={handleBack} />;
      case 4:
        return <ReviewAndSend 
                    credentials={credentials}
                    recipients={recipients}
                    emailTemplate={emailTemplate}
                    sendProgress={sendProgress}
                    isSending={isSending}
                    isCampaignFinished={isCampaignFinished}
                    scheduledTime={scheduledTime}
                    onScheduleOrSend={handleScheduleOrSend}
                    onCancelSchedule={cancelSchedule}
                    onBack={handleBack}
                    onReset={resetCampaign}
                />;
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto py-4 px-4 sm:px-6 lg:px-8">
          <h1 className="text-3xl font-bold leading-tight text-gray-900 text-center">
            StreamMail: Cold Email Outreach
          </h1>
        </div>
      </header>
      <main>
        <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
            <div className="mb-20">
                <StepIndicator currentStep={step} totalSteps={totalSteps} />
            </div>
            {renderStepContent()}
        </div>
      </main>
    </div>
  );
};

export default App;
