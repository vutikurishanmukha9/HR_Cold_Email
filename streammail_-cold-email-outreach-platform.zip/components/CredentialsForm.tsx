
import React, { useState } from 'react';
import { Credentials } from '../types';

interface CredentialsFormProps {
  onSave: (credentials: Credentials) => void;
}

const CredentialsForm: React.FC<CredentialsFormProps> = ({ onSave }) => {
  const [email, setEmail] = useState('');
  const [appPassword, setAppPassword] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim() || !/^\S+@\S+\.\S+$/.test(email)) {
      setError('Please enter a valid email address.');
      return;
    }
    if (!appPassword.trim() || appPassword.trim().length < 16) {
      setError('Please enter a valid 16-character Google App Password.');
      return;
    }
    setError('');
    onSave({ email, appPassword });
  };

  return (
    <div className="max-w-lg mx-auto">
        <h2 className="text-2xl font-semibold text-gray-700 text-center">Step 1: Connect Your Gmail Account</h2>
        <p className="text-center text-gray-500 mt-2">Enter your sender email and a Google App Password to send emails securely.</p>
        
        <div className="mt-6 bg-yellow-50 border-l-4 border-yellow-400 p-4 rounded-md">
            <div className="flex">
                <div className="flex-shrink-0">
                    <svg className="h-5 w-5 text-yellow-400" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                        <path fillRule="evenodd" d="M8.485 2.495c.673-1.167 2.357-1.167 3.03 0l6.28 10.875c.673 1.167-.17 2.625-1.516 2.625H3.72c-1.347 0-2.189-1.458-1.515-2.625L8.485 2.495zM10 5a.75.75 0 01.75.75v3.5a.75.75 0 01-1.5 0v-3.5A.75.75 0 0110 5zm0 9a1 1 0 100-2 1 1 0 000 2z" clipRule="evenodd" />
                    </svg>
                </div>
                <div className="ml-3">
                    <p className="text-sm text-yellow-700">
                        <span className="font-bold">Security Notice:</span> Your credentials are used only for sending emails during this session and are not stored. For information on creating an App Password, visit the{' '}
                        <a href="https://support.google.com/accounts/answer/185833" target="_blank" rel="noopener noreferrer" className="font-medium underline hover:text-yellow-800">
                            Google Help Center
                        </a>.
                    </p>
                </div>
            </div>
        </div>

        <form onSubmit={handleSubmit} className="mt-8 space-y-6">
            <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-700">Sender Email Address</label>
                <input
                    id="email"
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="you@gmail.com"
                    className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                    required
                />
            </div>
            <div>
                <label htmlFor="appPassword" className="block text-sm font-medium text-gray-700">Google App Password</label>
                <input
                    id="appPassword"
                    type="password"
                    value={appPassword}
                    onChange={(e) => setAppPassword(e.target.value)}
                    placeholder="•••• •••• •••• ••••"
                    className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                    required
                    minLength={16}
                    maxLength={16}
                />
            </div>
            {error && <p className="text-sm text-red-600">{error}</p>}
            <div className="flex justify-end">
                <button
                    type="submit"
                    className="inline-flex justify-center py-2 px-6 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50"
                    disabled={!email || !appPassword}
                >
                    Save & Continue
                </button>
            </div>
        </form>
    </div>
  );
};

export default CredentialsForm;
